'use strict';

var Club = function() {
  this.id = "";
  this.name = "";
};
