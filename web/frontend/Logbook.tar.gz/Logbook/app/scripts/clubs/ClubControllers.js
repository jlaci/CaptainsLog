'use strict';

angular.module('logbookApp')
  .controller('ClubsController', function ($scope, ClubService) {


  }
);
