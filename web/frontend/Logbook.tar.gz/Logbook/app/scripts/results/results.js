'use strict';

/**
 * @ngdoc function
 * @name logbookApp.controller:ResultsController
 * @description
 * # ResultsController
 * Controller of the logbookApp
 */
angular.module('logbookApp')
  .controller('ResultsController', function () {

  });
