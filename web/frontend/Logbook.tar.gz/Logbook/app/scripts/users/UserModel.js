'use strict';

var User = function() {
  this.username = "";
  this.email = "";
  this.id = "";
};

var Credentials = function() {
  this.principal = "";
  this.secret = "";
};
