'use strict';



/**
 * @ngdoc overview
 * @name logbookApp
 * @description
 * # logbookApp
 *
 * Main module of the application.
 */
var logbookApp = angular
  .module('logbookApp', [
    'ngAnimate',
    'ngCookies',
    'ngResource',
    'ngRoute',
    'ngSanitize',
    'ngTouch',
    'logbookApp.services',
    'ui.bootstrap',
    'growlNotifications'
  ]
);

var serviceModule = angular
  .module('logbookApp.services', []
);

serviceModule.value('restServiceUrl', '/api');

logbookApp.config(["$routeProvider", "$httpProvider", function ($routeProvider, $httpProvider) {

    $httpProvider.defaults.useXDomain = true;
    $httpProvider.defaults.withCredentials = true;


    $routeProvider
      .when('/', {
        templateUrl: 'views/main.html',
        controller: 'MainCtrl',
        controllerAs: 'main'
      })
      .when('/boats', {
        templateUrl: 'views/boats/overview.html',
        controller: 'BoatsController',
        controllerAs: 'boats'
      })
      .when('/boats/new', {
        templateUrl: 'views/boats/editor.html',
        controller: 'BoatEditorController',
        controllerAs: 'boatsEdit'
      })
      .when('/boats/:boatId/edit', {
        templateUrl: 'views/boats/editor.html',
        controller: 'BoatEditorController',
        controllerAs: 'boatsEdit'
      })
      .when('/regattas', {
        templateUrl: 'views/regattas/overview.html',
        controller: 'RegattasController',
        controllerAs: 'regattas'
      })
      .when('/regattas/new', {
        templateUrl: 'views/regattas/editor.html',
        controller: 'RegattaEditorController',
        controllerAs: 'regattasEdit'
      })
      .when('/regattas/:regattaId/edit', {
        templateUrl: 'views/regattas/editor.html',
        controller: 'RegattaEditorController',
        controllerAs: 'regattasEdit'
      })
      .when('/results', {
        templateUrl: 'views/results.html',
        controller: 'ResultsController',
        controllerAs: 'results'
      })
      .when('/user/profile', {
        templateUrl: 'views/users/profile.html',
        controller: 'UserController',
        controllerAs: 'users'
      })
      .otherwise({
        redirectTo: '/'
      });


    var interceptor = ['$q', '$location', '$injector', '$rootScope',
      function ($q, $location, $injector, $rootScope) {
        return {
          response: function (response) {
            return response;
          },
          responseError: function (response) {
            if (response.status == 401) {
              $rootScope.authenticated = false;
              $location.path("/");
              return $q.reject(response);
            }
            return $q.reject(response);
          }
        }
      }];

    $httpProvider.interceptors.push(interceptor);
  }]
);


logbookApp.run(["$rootScope", "$cookies", "UserService", "BoatService", function($rootScope, $cookies, UserService, BoatService) {

  $rootScope.authenticated = false;
  $rootScope.user = {};

  //If we have a previous session try to re use it
  if ($cookies.get('authenticated') != undefined) {
    UserService.getDetails().success(function (data) {
      $rootScope.authenticated = true;
      $rootScope.user = data;

      //List the boats for the user
      BoatService.getOwn(function(result) {
        $rootScope.user.availableBoats = result;

        if(result != null && result.length > 0) {
          $rootScope.user.selectedBoat = result[0].id;
        }
      });
    }).error(function() {
      $cookies.remove('authenticated');
    });
  }
}]);


'use strict';

/**
 * @ngdoc function
 * @name logbookApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the logbookApp
 */
angular.module('logbookApp')
  .controller('MainCtrl', ["$scope", function ($scope) {
    $scope.notifications = {};
    $scope.notificationIndex = 0;

    $scope.addNotification = function(notification){
      $scope.notifications[$scope.notificationIndex++] = notification;
    };
  }]);

/**
 * @ngdoc function
 * @name logbookApp.controller:HeaderController
 * @description
 * # MainCtrl
 * Controller for the header.
 */
angular.module('logbookApp')
  .controller('HeaderController', ["$scope", "$location", function ($scope, $location) {
    $scope.isActive = function (viewLocation) {
      return viewLocation === $location.path();
    };
  }]);

'use strict';

var Club = function() {
  this.id = "";
  this.name = "";
};

"use strict";

serviceModule.factory('ClubService', ['$resource', 'restServiceUrl', function ClubService($resource, restServiceUrl) {
  var Club = $resource(restServiceUrl + "/club/");

  return {
    getAll : function(callback) {
      Club.query(callback);
    }
  };
}]);

'use strict';

angular.module('logbookApp')
  .controller('ClubsController', ["$scope", "ClubService", function ($scope, ClubService) {


  }]
);

'use strict';

var User = function() {
  this.username = "";
  this.email = "";
  this.id = "";
};

var Credentials = function() {
  this.principal = "";
  this.secret = "";
};

'use strict';

serviceModule.factory('UserService', ['$http', 'restServiceUrl', '$rootScope', function UserService($http, restServiceUrl, $rootScope) {
  return {
    authenticate: function (credentials) {
      var authString = credentials.principal + ":" + credentials.secret;

      var req = {
        method: 'GET',
        url: restServiceUrl + '/user',
        headers: {
          'Authorization': 'Basic ' + btoa(authString)
        }
      };
      return $http(req);
    },
    getDetails : function() {
      var req = {
        method: 'GET',
        url: restServiceUrl + '/user/current'
      };
      return $http(req);
    }
  };
}]);

'use strict';

angular.module('logbookApp').controller('UserController', ["$scope", "$http", "$rootScope", "$cookies", "UserService", "BoatService", function UserController($scope, $http, $rootScope, $cookies, UserService, BoatService) {

  $scope.authenticate = function () {

    //Construct the credentials object
    var credentials = new Credentials();
    credentials.principal = $scope.principal;
    credentials.secret = $scope.secret;

    //Authenticate with the server
    UserService.authenticate(credentials).success(function (data, status, headers) {
      if (status == 200) {
        UserService.getDetails().success(function (data) {
          $rootScope.authenticated = true;
          $rootScope.user = data;
          $cookies.put("authenticated", "true");

          //List the boats for the user
          BoatService.getOwn(function(result) {
            $rootScope.user.availableBoats = result;

            if(result != null && result.length > 0) {
              $rootScope.user.selectedBoat = result[0].id;
            }
          });
        });
      }
    }).error(function (data, status){
      $rootScope.authenticated = false;
      if(status == 400 || status == 403){
        alert("Wrong username or password! (" + status + ")");
      } else {
        alert("Error while connecting to server! " + status);
      }
    });
  };

  $scope.logout = function() {
    $rootScope.authenticated = false;
    $rootScope.user = {};
    $cookies.remove('authenticated');
  }
}]);

"use strict";

serviceModule.factory('BoatService', ['$resource', 'restServiceUrl', function BoatService($resource, restServiceUrl) {
  var Boats = $resource(
    restServiceUrl + "/boat/:id",
    {
      id:'@id'
    },
    {
      withCredentials : true,
      'update':
      {
        method : 'PUT'
      },
      'getOwn':
      {
        method : 'GET',
        url : restServiceUrl + "/boat/own",
        isArray : true
      }
    }
  );

  return {
    getAll : function(callback) {
      Boats.query(callback);
    },
    getOwn : function (callback) {
      Boats.getOwn().$promise.then(callback);
    }
  };
}]);

angular.module('logbookApp')
  .controller('BoatsController', ["$scope", "BoatService", function ($scope, BoatService) {

    BoatService.getAll(function(boats) {
      $scope.boats = boats;
    });

  }]);

angular.module('logbookApp')
  .controller('BoatEditorController', ["$scope", "BoatService", function ($scope, BoatService) {

  }]);

'use strict';

var Regatta = function() {
  this.id = "";
  this.name = "";
  this.type = "TOURING";
  this.organizer = {
    id: "",
    name: ""
  };
  this.location = "";
  this.startDate = new Date();
  this.endDate = new Date();
  this.races = [];
};

var Race = function() {
  this.id = "";
  this.order = 0;
  this.type = "TOURING";
  this.startDate = new Date();
  this.endDate = new Date();
};

"use strict";

serviceModule.factory('RegattaService', ['$resource', 'restServiceUrl', function RegattaService($resource, restServiceUrl) {
  var Regattas = $resource(restServiceUrl + "/regatta/:id", {id:'@id'}, { withCredentials : true, 'update': {method : 'PUT'}});

  return {
    getAll : function(callback) {
      Regattas.query(callback);
    },
    getOne : function(id, callback) {
      Regattas.get({id: id}).$promise.then(callback);
    },
    update : function (id, data, callback) {
      Regattas.update({id: id}, data).$promise.then(callback);
    },
    save : function(data, callback) {
      var newRegatta = new Regattas(data);
      newRegatta.$save(callback);
    },
    delete : function(id, callback) {
      var regatta = new Regattas({id:id});
      regatta.$delete(callback);
    }
  };

}]);

'use strict';

/**
 * @ngdoc function
 * @name logbookApp.controller:RegattasController
 * @description
 * # RegattasController
 * Controller of the logbookApp
 */
angular.module('logbookApp')
  .controller('RegattasController', ["$scope", "RegattaService", function ($scope, RegattaService) {

    //Utility functions
    $scope.parseDate = function(date) {
      return new Date(date);
    };

    $scope.parseType = function(type) {
      if(type === 'TOURING') {
        return "Túra";
      } else if(type === 'MIXED') {
        return "Vegyes";
      } else if (type === 'COURSE') {
        return "Pálya";
      } else {
        return "Ismeretlen";
      }
    };

    $scope.delete = function(regatta) {
      RegattaService.delete(regatta.id, function() {
        $scope.addNotification("Sikeres törlés!");
        $scope.regattas.splice($scope.regattas.indexOf(regatta), 1);
        sortToSeasons($scope.regattas);
      });
    };


    function sortToSeasons(regattas) {
      var seasons = [];
      var seasonsByYear = {};

      for (var i = 0; i < regattas.length; i++) {
        var year = new Date(regattas[i].startDate).getFullYear();
        if(seasonsByYear[year] == null) {
          seasonsByYear[year] = {
            date : year,
            regattas : []
          };
          seasons.push(seasonsByYear[year]);
        }
        seasonsByYear[year].regattas.push(regattas[i]);
      }

      //Sort the seasons
      seasons.sort(function(s1, s2) {
        return s2.date - s1.date;
      });

      //Sort the races in seasons
      for(var i = 0; i < seasons.length; i++) {
        seasons[i].regattas.sort(function(r1, r2) {
          return r1.startDate - r2.startDate;
        });
      }

      $scope.seasons = seasons;
    }


    //Fill the page with data, by seasons
    RegattaService.getAll(function(regattas) {
      $scope.regattas = regattas;
      sortToSeasons(regattas);
    });

  }]
);

angular.module('logbookApp')
  .controller('RegattaEditorController', ["$scope", "$routeParams", "$location", "RegattaService", "ClubService", function ($scope, $routeParams, $location, RegattaService, ClubService) {

    function createNew() {
      $scope.regatta = new Regatta();
      $scope.editMode = false;

      var d = new Date();
      d.setHours(9);
      d.setMinutes(0);
      $scope.regatta.startDate = d;
      $scope.regatta.endDate = d;

      $scope.lastRaceNumber = 0;

      if($scope.clubs != null && $scope.clubs.length > 0) {
        $scope.regatta.organizer.id = $scope.clubs[0].id;
      }
    }

    function loadExisting(regatta) {
      $scope.regatta = regatta;
      $scope.editMode = true;
      $scope.regatta = regatta;

      $scope.lastRaceNumber = regatta.races.length;
    }

    function initialize() {
      //Get the available organizing clubs
      ClubService.getAll(function(result) {
        $scope.clubs = result;

        if($scope.clubs != null && $scope.clubs.length > 0 && $scope.editMode === false) {
          $scope.regatta.organizer.id = $scope.clubs[0].id;
        }
      });

      //Set up the datepickers
      $scope.dateOptions = {
        formatYear: 'yy',
        startingDay: 1
      };
      $scope.datePickerStates = {};

      //Check if we are editing or creating a new
      if ($routeParams.regattaId !== undefined) {
        RegattaService.getOne($routeParams.regattaId, function (regatta) {
          loadExisting(regatta);
        });
      } else {
        createNew();
      }
    }

    initialize();

    $scope.addRace = function () {
      var race = new Race();
      race.order = ++$scope.lastRaceNumber;
      race.startDate = $scope.regatta.startDate;
      race.endDate = $scope.regatta.endDate;

      $scope.regatta.races.push(race);
    };

    $scope.removeRace = function(raceNumber) {
      $scope.regatta.races.splice(raceNumber - 1, 1);

      for(var i = 0; i < $scope.regatta.races.length; i++) {
       $scope.regatta.races[i].order = i + 1;
      }

      $scope.lastRaceNumber = $scope.regatta.races.length;
    };

    $scope.moveRaceUp = function(raceNumber) {
      var index = raceNumber - 1;

      if(index >= 1 && index < $scope.regatta.races.length) {
        var aboveIndex = index - 1;
        var above = $scope.regatta.races[aboveIndex];
        var current = $scope.regatta.races[index];

        current.order = above.order;
        $scope.regatta.races[aboveIndex] = current;

        above.order = current.order + 1;
        $scope.regatta.races[index] = above;
      }
    };

    $scope.moveRaceDown = function(raceNumber) {
      $scope.moveRaceUp(raceNumber + 1);
    };

    $scope.save = function() {
      if($scope.editMode === true) {
        RegattaService.update($scope.regatta.id, $scope.regatta, function() {
          $scope.addNotification("Sikeres frissítés!");
          $location.path("/regattas")
        });
      } else {
        RegattaService.save($scope.regatta, function() {
          $scope.addNotification("Sikeres mentés!");
          $location.path("/regattas");
        });
      }
    };
  }]
);

'use strict';

/**
 * @ngdoc function
 * @name logbookApp.controller:ResultsController
 * @description
 * # ResultsController
 * Controller of the logbookApp
 */
angular.module('logbookApp')
  .controller('ResultsController', function () {

  });

angular.module('logbookApp').run(['$templateCache', function($templateCache) {
  'use strict';

  $templateCache.put('views/boats/editor.html',
    "<form class=\"form-horizontal\"> <fieldset> <!-- Form Name --> <legend>Hajó módosítása /&nbsp;Új hajó felvitele</legend> <!-- Text input--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"hajoneve\">Hajónév</label> <div class=\"col-md-4\"> <input id=\"hajoneve\" name=\"hajoneve\" type=\"text\" placeholder=\"hajoneve\" class=\"form-control input-md\"> <span class=\"help-block\">Új hajó neve</span> </div> </div> <!-- Prepended text--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"vitorlaszam\">Vitorlaszám</label> <div class=\"col-md-4\"> <div class=\"input-group\"> <span class=\"input-group-addon\">HUN-</span> <input id=\"vitorlaszam\" name=\"vitorlaszam\" class=\"form-control\" placeholder=\"vitorlaszam\" type=\"text\"> </div> <p class=\"help-block\">Vitorlaszám a HUN- előtag nélkül</p> </div> </div> <!-- Select Basic --> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"hajotipus\">Hajótípus</label> <div class=\"col-md-4\"> <select id=\"hajotipus\" name=\"hajotipus\" class=\"form-control\"> <option value=\"1\">Option one</option> <option value=\"2\">Option two</option> </select> </div> </div> <!-- Select Basic --> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"kikoto\">Kikötő</label> <div class=\"col-md-4\"> <select id=\"kikoto\" name=\"kikoto\" class=\"form-control\"> <option value=\"1\">Option one</option> <option value=\"2\">Option two</option> </select> </div> </div> <!-- Select Basic --> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"egyesulet\">Egyesület</label> <div class=\"col-md-4\"> <select id=\"egyesulet\" name=\"egyesulet\" class=\"form-control\"> <option value=\"1\">Option one</option> <option value=\"2\">Option two</option> </select> </div> </div> <!-- Text input--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"tulajdonos\">Tulajdonos</label> <div class=\"col-md-4\"> <input id=\"tulajdonos\" name=\"tulajdonos\" type=\"text\" placeholder=\"tulajdonos\" class=\"form-control input-md\"> <span class=\"help-block\">Tulajdonos /&nbsp;kormányos</span> </div> </div> <!-- Text input--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"telefonszam\">Telefonszám</label> <div class=\"col-md-4\"> <input id=\"telefonszam\" name=\"telefonszam\" type=\"text\" placeholder=\"telefonszam\" class=\"form-control input-md\"> <span class=\"help-block\">Tulajdonos telefonszáma</span> </div> </div> <!-- Text input--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"emailcim\">E-mail cím</label> <div class=\"col-md-4\"> <input id=\"emailcim\" name=\"emailcim\" type=\"text\" placeholder=\"emailcom\" class=\"form-control input-md\"> <span class=\"help-block\">Tulajdonos e-mail címe</span> </div> </div> <!-- Button (Double) --> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"okbutton\"></label> <div class=\"col-md-8\"> <button id=\"okbutton\" name=\"okbutton\" class=\"btn btn-success\">Mentés</button> <button id=\"cancelbutton\" name=\"cancelbutton\" class=\"btn btn-danger\">Mégsem</button> </div> </div> </fieldset> </form>"
  );


  $templateCache.put('views/boats/overview.html',
    "<div class=\"text-center\"><a href=\"#/boats/new\"><i class=\"fa fa-plus fa-fw\"></i>Új hajó felvétele</a></div> <hr> <table class=\"table\"> <tr> <th>Hajó neve</th> <th>Vitorlaszáma</th> <th>Típusa</th> <th>Kikötő</th> <th>Egyesület</th> <th>Tulajdonos</th> <th>Műveletek</th> </tr> <tr ng-repeat=\"boat in boats\"> <td>{{boat.name}}</td> <td>{{boat.sailNumber}}</td> <td></td> <td></td> <td></td> <td></td> <td> <a><i class=\"fa fa-list fa-fw\"></i>Legénység</a> &nbsp; <a href=\"#/boats/{{boat.id}}/edit\"><i class=\"fa fa-pencil fa-fw\"></i>Szerkesztés</a> &nbsp; <a ng-click=\"delete(boat)\"><i class=\"fa fa-trash fa-fw\"></i>Törlés</a> </td> </tr> </table>"
  );


  $templateCache.put('views/main.html',
    "<h1>Hajónapló oldal.</h1> <p>Üdv a hajónapló oldalon!</p> <p ng-if=\"!authenticated\">Jelentkezz be hogy lásd a további funkciókat!</p>"
  );


  $templateCache.put('views/regattas/editor.html',
    "<form class=\"form-horizontal\" ng-controller=\"RegattaEditorController\"> <fieldset> <!-- Form Name --> <legend>Verseny</legend> <div class=\"row\"> <div class=\"col-md-6\"> <!-- Regatta name--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_name\">Verseny neve:</label> <div class=\"col-md-6\"> <input id=\"regatta_name\" name=\"regatta_name\" type=\"text\" placeholder=\"Név\" class=\"form-control input-md\" required ng-model=\"regatta.name\"> </div> </div> <!-- Regatta type --> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_type\">Típusa</label> <div class=\"col-md-6\"> <select id=\"regatta_type\" name=\"regatta_type\" class=\"form-control\" ng-model=\"regatta.type\"> <option value=\"TOURING\">Túra</option> <option value=\"COURSE\">Pálya</option> <option value=\"MIXED\">Vegyes</option> </select> </div> </div> </div> <div class=\"col-md-6\"> <!-- Regatta location--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_location\">Verseny helye:</label> <div class=\"col-md-6\"> <input id=\"regatta_location\" name=\"regatta_location\" type=\"text\" placeholder=\"Hely\" class=\"form-control input-md\" required ng-model=\"regatta.location\"> </div> </div> <!-- Organizing club --> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_club\">Szervező egyesület:</label> <div class=\"col-md-6\"> <select id=\"regatta_club\" name=\"regatta_club\" class=\"form-control\" ng-model=\"regatta.organizer.id\" ng-options=\"c.id as c.name for c in clubs\"> </select> </div> </div> </div> </div> <hr> <div class=\"row\"> <div class=\"col-md-6\"> <!-- Start date--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_start_date\">Kezdés dátuma</label> <div class=\"col-md-6\"> <p class=\"input-group\"> <input id=\"regatta_start_date\" type=\"text\" class=\"form-control\" uib-datepicker-popup=\"yyyy/MM/dd\" ng-model=\"regatta.startDate\" is-open=\"datePickerStates['regattaStart']\" datepicker-options=\"dateOptions\" ng-required=\"true\" close-text=\"Close\"> <span class=\"input-group-btn\"> <button type=\"button\" class=\"btn btn-default\" ng-click=\"datePickerStates['regattaStart'] = true\"><i class=\"glyphicon glyphicon-calendar\"></i></button> </span> </p> </div> </div> <!-- Start time--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_start_time\">Kezdés ideje</label> <div class=\"col-md-6\"> <uib-timepicker id=\"regatta_start_time\" ng-model=\"regatta.startDate\" hour-step=\"1\" minute-step=\"5\" show-meridian=\"false\"></uib-timepicker> </div> </div> </div> <div class=\"col-md-6\"> <!-- End date--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_end_date\">Befejezés dátuma</label> <div class=\"col-md-6\"> <p class=\"input-group\"> <input id=\"regatta_end_date\" type=\"text\" class=\"form-control\" uib-datepicker-popup=\"yyyy/MM/dd\" ng-model=\"regatta.endDate\" is-open=\"datePickerStates['regattaEnd']\" datepicker-options=\"dateOptions\" ng-required=\"true\" close-text=\"Close\"> <span class=\"input-group-btn\"> <button type=\"button\" class=\"btn btn-default\" ng-click=\"datePickerStates['regattaEnd'] = true\"><i class=\"glyphicon glyphicon-calendar\"></i></button> </span> </p> </div> </div> <!-- End time--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"regatta_end_time\">Befejezés ideje</label> <div class=\"col-md-6\"> <uib-timepicker id=\"regatta_end_time\" ng-model=\"regatta.endDate\" hour-step=\"1\" minute-step=\"5\" show-meridian=\"false\"></uib-timepicker> </div> </div> </div> </div> <legend>Futamok</legend> <table class=\"table\"> <tr> <th>#</th> <th>Kezdés ideje</th> <th>Befejezés ideje</th> <th>Típusa</th> <th>Műveletek</th> </tr> <tr ng-repeat=\"race in regatta.races\"> <!-- Race order in regatta --> <td class=\"col-md-1\"><b>{{race.order}}</b></td> <!-- Race start date --> <td class=\"col-md-4\"> <div class=\"row\"> <div class=\"col-md-8\"> <p class=\"input-group\"> <input type=\"text\" class=\"form-control\" uib-datepicker-popup=\"yyyy/MM/dd\" ng-model=\"race.startDate\" is-open=\"datePickerStates['race' + race.order + 'Start']\" datepicker-options=\"dateOptions\" ng-required=\"true\" close-text=\"Close\"> <span class=\"input-group-btn\"> <button type=\"button\" class=\"btn btn-default\" ng-click=\"datePickerStates['race' + race.order + 'Start'] = true\"><i class=\"glyphicon glyphicon-calendar\"></i></button> </span> </p> </div> <div class=\"col-md-4\"> <uib-timepicker ng-model=\"race.startDate\" hour-step=\"1\" minute-step=\"5\" show-meridian=\"false\" show-spinners=\"false\"></uib-timepicker> </div> </div> </td> <!-- Race end date --> <td class=\"col-md-4\"> <div class=\"row\"> <div class=\"col-md-8\"> <p class=\"input-group\"> <input type=\"text\" class=\"form-control\" uib-datepicker-popup=\"yyyy/MM/dd\" ng-model=\"race.endDate\" is-open=\"datePickerStates['race' + race.order + 'End']\" datepicker-options=\"dateOptions\" ng-required=\"true\" close-text=\"Close\"> <span class=\"input-group-btn\"> <button type=\"button\" class=\"btn btn-default\" ng-click=\"datePickerStates['race' + race.order + 'End'] = true\"><i class=\"glyphicon glyphicon-calendar\"></i></button> </span> </p> </div> <div class=\"col-md-4\"> <uib-timepicker ng-model=\"race.endDate\" hour-step=\"1\" minute-step=\"5\" show-meridian=\"false\" show-spinners=\"false\"></uib-timepicker> </div> </div> </td> <!-- Race type --> <td class=\"col-md-1\"> <select class=\"form-control\" ng-model=\"race.type\"> <option value=\"TOURING\">Túra</option> <option value=\"COURSE\">Pálya</option> </select> </td> <!-- Operations --> <td class=\"col-md-2\"> <a ng-click=\"moveRaceUp(race.order)\"><i class=\"fa fa-arrow-up fa-fw\"></i>Fel</a> <a ng-click=\"moveRaceDown(race.order)\"><i class=\"fa fa-arrow-down fa-fw\"></i>Le</a> <a ng-click=\"removeRace(race.order)\"><i class=\"fa fa-trash fa-fw\"></i>Törlés</a> </td> </tr> </table> <div class=\"text-center\"><a ng-click=\"addRace()\"><i class=\"fa fa-plus fa-fw\"></i>Új futam</a></div> </fieldset> <hr> <div class=\"text-center\"> <a class=\"btn btn-danger\" href=\"#/regattas\"><i class=\"fa fa-times\"></i>&nbsp;Mégsem</a> <a class=\"btn btn-success\" ng-click=\"save()\"><i class=\"fa fa-floppy-o\"></i>&nbsp;Mentés</a> </div> <br> <pre>{{regatta}}</pre> </form>"
  );


  $templateCache.put('views/regattas/overview.html',
    "<div class=\"text-center\"><a href=\"#/regattas/new\"><i class=\"fa fa-plus fa-fw\"></i>Új verseny felvétele</a></div> <hr> <div ng-repeat=\"season in seasons\"> <div class=\"text-center\"> <h3>{{season.date}}</h3> </div> <table class=\"table\"> <tr> <th>Név</th> <th>Kezdés ideje</th> <th>Befejezés ideje</th> <th>Típusa</th> <th>Szervező egyesület</th> <th>Hely</th> <th>Műveletek</th> </tr> <tr ng-repeat=\"regatta in season.regattas\"> <td>{{regatta.name}}</td> <td>{{parseDate(regatta.startDate) | date:'medium'}}</td> <td>{{parseDate(regatta.endDate) | date:'medium'}}</td> <td>{{parseType(regatta.type)}}</td> <td>{{regatta.organizer.name}}</td> <td>{{regatta.location}}</td> <td> <a><i class=\"fa fa-eye fa-fw\"></i>Eredmények</a> &nbsp; <a href=\"#/regattas/{{regatta.id}}/edit\"><i class=\"fa fa-pencil fa-fw\"></i>Szerkesztés</a> &nbsp; <a ng-click=\"delete(regatta)\"><i class=\"fa fa-trash fa-fw\"></i>Törlés</a> </td> </tr> </table> </div>"
  );


  $templateCache.put('views/results.html',
    "<p>Eredmények.</p>"
  );


  $templateCache.put('views/users/profile.html',
    "<h1>Profilom</h1> <form class=\"form-horizontal\"> <fieldset> <!-- Form Name --> <legend>Form Name</legend> <!-- Text input--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"textinput\">Felhasználónév</label> <div class=\"col-md-4\"> <input id=\"textinput\" name=\"textinput\" type=\"text\" placeholder=\"Név\" class=\"form-control input-md\" ng-model=\"user.username\"> </div> </div> <!-- Text input--> <div class=\"form-group\"> <label class=\"col-md-4 control-label\" for=\"email\">Email</label> <div class=\"col-md-4\"> <input id=\"email\" name=\"email\" type=\"text\" placeholder=\"email\" class=\"form-control input-md\" ng-model=\"user.email\"> </div> </div> </fieldset> </form>"
  );

}]);
